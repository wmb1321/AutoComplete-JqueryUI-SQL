﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Json;

namespace AutoCompleteDemo
{
    public partial class AutoCompleteForm : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (this.Request.Params["term"] != null)
            {
                string json = "{\"val1\":\"Joe\", \"val2\":\"Henry\"}";
                Response.Clear();
                Response.ContentType = "application/json; charset=utf-8";
                Response.Write(json);
                Response.End();
            }
        }

        protected void method()
        {
            
        }
    }
}